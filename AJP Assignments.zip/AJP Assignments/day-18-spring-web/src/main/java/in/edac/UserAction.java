package in.edac;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
public class UserAction{
	
	@GetMapping("/")
	public List<User> getUsers() {
		List<User> list = new ArrayList<User>();
		return list;
		
		
	}
	
	
	
	@GetMapping("/{id}")	//path variable (to make dynamic)
	public User getSingleUser(@PathVariable int id) {
		User user = new User(id,"mum","243323423","m@gmail.com","4534545");
		return user;
	}
	
	
	@PostMapping("/")
	public User createUser(User user) {
		//create object in database
		return user;
	}
	
	
	@PutMapping("/{id}")
	public User updateUser(@PathVariable int id,User user) {
		//.... update the record in database
		return user;
	}
	
	@DeleteMapping("/id")
	public int deleteUser(@PathVariable int id) {
		return id;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
package edac;

import java.util.Arrays;
import java.util.List;

public class StreamDemo {

	public static void main(String[] args) {
	
		List<Employee> l = Arrays.asList(
				new Employee("Nagpur"),
				new Employee("Pune"),
				new Employee("Mumbai"),
				new Employee("Jalgaon")
				); 
		
//		System.out.println(l);
		
		l.stream().sorted((e1, e2) -> e2.getTitle()
				.compareTo(e1.getTitle()))
				.forEach((e) -> System.out.println(e.getTitle()));
	}

}

class Employee{
	private String title;
	
	public Employee(String title) {
		this.title=title;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	
}



package in.edac;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface User16Repository extends JpaRepository<User16,Integer> {
	
	List<User16> findByUsernameOrEmail(String username,String email);

}

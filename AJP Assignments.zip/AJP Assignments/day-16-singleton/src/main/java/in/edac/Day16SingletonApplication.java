package in.edac;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day16SingletonApplication implements CommandLineRunner {
	
	@Autowired
	User16Repository userRepository;

	public static void main(String[] args) {
		SpringApplication.run(Day16SingletonApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("HELLO SPRING THIS IS A RUN METHOD");
//		create();
//		update();
//		findAndUpdate();
//		delete();
//		findAll();
		queryDemo();

	}
	
	
	public void queryDemo() {
		List<User16> list = userRepository.findByUsernameOrEmail("kiran", "maske@gmail.com");
		list.stream().map(User16::getUsername).forEach(System.out::println);
		
		
//		List<User16> list = userRepository.findUsernameAndPwd("rajat", "5565555");
//		list.stream().map(User16::getUsername).forEach(System.out::println);
		
	}
	
	
	
	
	
	
	

	
	
	

	
	
	
	
	

	public void findAll() {
		
		List<User16> list =  userRepository.findAll();
		list.stream().map(User16::getUsername).forEach(System.out::println);
	}
	

	
	
	
	public void delete() {
		userRepository.deleteById(4);
	}
	
	
	
	
	
	public void findAndUpdate() {
		User16 user = userRepository.findById(3).get();
		user.setUsername("MANOJ");
		userRepository.save(user);
		
	}
	
	
	
	
	
	
	public void update() {
		User16 user = new User16();
		user.setId(1);
		user.setUsername("kiran");
		user.setEmail("kiran@gmail.com");
		userRepository.save(user);
	}
	
	
	
	public void create() {
		User16 user = new User16("rajat","5565555","rajat@gmail.com","3434767");
		userRepository.save(user);
		
		User16 user1 = new User16("wankhede","5565555","wankhede@gmail.com","3434767");
		userRepository.save(user1);
		
		User16 user2 = new User16("maske","5565555","maske@gmail.com","3434767");
		userRepository.save(user2);
		
		User16 user3 = new User16("milind","5565555","milind@gmail.com","3434767");
		userRepository.save(user3);
	}
	

}

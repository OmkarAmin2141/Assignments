package in.edac;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Hellosrvlet12
 */
@WebServlet("/Hellosrvlet12")
public class Hellosrvlet12 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			String method = request.getMethod().toLowerCase();
			String name = request.getParameter("name");
			PrintWriter out = response.getWriter();
			if("get".equals(method)) {
				out.println("GET: HELLO "+ name +" !!!");
			}
			if("post".equals(method)){
				out.println("POST: HELLO "+ name +" !!!");
			}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

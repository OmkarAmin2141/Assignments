package in.edac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/*
 * CURD - Create Update Read Delete
 */

public class UserDao {
	
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3307/edac2";
	public static final String DB_USERNAME = "root";
	public static final String DB_PASSWORD = "Edac20";

	

public void createUser(User user) throws Exception{
	
	Class.forName(DB_DRIVER);
	try (Connection con = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);)
			
		 {
		
		
		String sql = "INSERT INTO USER1 (USERNAME, PASSWORD,EMAIL, MOBILE) VALUES (?,?,?,?)" ;
		
		
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, user.getUsername());
		ps.setString(2, user.getPassword());
		ps.setString(3, user.getEmail());
		ps.setString(4, user.getMobile());
		ps.executeUpdate();
		System.out.println("INSERT SUCCESSFUL !!! ");
		

		 } catch (Exception e) {
		e.printStackTrace();
	}
}



public void updateUser(User user) throws Exception{
	Class.forName(DB_DRIVER);
	try(Connection con = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)){
		
		
		String sql = "UPDATE USER1 SET USERNAME=?, EMAIL=? WHERE ID=?";
		PreparedStatement ps =  con.prepareStatement(sql);
		ps.setString(1, user.getUsername());
		ps.setString(2, user.getEmail());
		ps.setInt(3, user.getId());
		ps.executeUpdate();
		
		System.out.println("UPDATE SUCCESSFUL ");
	}catch(Exception e) {
		e.printStackTrace();
	}
	
}

public void deleteUser(User user) throws Exception {
	Class.forName(DB_DRIVER);
	try (Connection con = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)){
		
		String sql = "DELETE FROM USER1 WHERE ID = ?";
		PreparedStatement ps =  con.prepareStatement(sql);
		ps.setInt(1, user.getId());
		ps.executeUpdate();
		System.out.println(" DELETED SUCCESSFULLY ");
		
	} catch (Exception e) {
	
		e.printStackTrace();
	}
}




public List<User> readAllUser() throws Exception{
	Class.forName(DB_DRIVER);
	try(Connection con = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)){
		String sql = "SELECT * FROM USER1";
		PreparedStatement ps =  con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		List<User> list = new ArrayList<User>();
		while(rs.next()) {
			int id = rs.getInt("ID");
			String username = rs.getString("USERNAME");
			String email = rs.getString("EMAIL");
			String mobile = rs.getString("MOBILE");
			
			User user = new User();
			user.setId(id);
			user.setUsername(username);
			user.setEmail(email);
			user.setMobile(mobile);
			
			list.add(user);
		}
		
		return list;
		
	}catch(Exception e) {
		throw e;
	}
}










public static void main(String[] args) throws Exception{
	
	UserDao ud = new UserDao();
//	User user = new User("a2","1234","a2@gmail.com","6543456");
//	User user2 = new User("a3","12345","a3@gmail.com","6543545456");
//	ud.createUser(user);
//	ud.createUser(user2);
//	User user = new User("Naman","12345","naman@gmail.com","123232323");
//	user.setId(2);
//	ud.updateUser(user);
//	User user = new User();
//	user.setId(3);
//	ud.deleteUser(user);
	
//	List<User> l = ud.readAllUser();
//	System.out.println(l);
	
	
}


	
}

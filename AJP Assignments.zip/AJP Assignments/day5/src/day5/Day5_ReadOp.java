package day5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Day5_ReadOp {
	public static void main(String[] args) throws Exception {
		Connection con = null;
		try {

			Scanner sc = new Scanner(System.in);

//			System.out.println("Enter id : ");
//			int id = sc.nextInt();

			// dynamically loading the class driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Database path
			String url = "jdbc:mysql://localhost:3307/edac1";
			String username = "root";
			String password = "Edac20";

			// open connection
			con = DriverManager.getConnection(url, username, password);
			String sql = "SELECT * FROM USER2";
			PreparedStatement ps = con.prepareStatement(sql);
//			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				String country = rs.getString("COUNTRY");
				String city = rs.getString("CAPITAL");
				System.out.println(country + " " + city);
			}

//			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// close connection
			con.close();
		}

	}

}

package day5;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
public class Day5_sql_Delete {
	public static void main(String[] args) {
		try {
			
			Scanner sc= new Scanner(System.in);
			
			
			System.out.println("Enter id : ");
			int id = sc.nextInt();
			
			//dynamically loading the class driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Database path
			String url = "jdbc:mysql://localhost:3307/edac1";
			String username = "root";
			String password = "Edac20";
			
			//open connection
			Connection con = DriverManager.getConnection(url,username,password);
			String sql = "DELETE FROM USER2 WHERE ID = ? ";
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setInt(1, id);
//			ps.executeUpdate();
			//close connection
			con.close();
		}catch(Exception e) {
			e.printStackTrace();
		}

}




}

package day5;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
public class Day5_Demo {
	public static void main(String[] args) {
		try {
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter country Name : ");
			String country = sc.nextLine();
			System.out.println("Enter capital Name : ");
			String capital = sc.nextLine();
			
			//dynamically loading the class driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Database path
			String url = "jdbc:mysql://localhost:3307/edac1";
			String username = "root";
			String password = "Edac20";
			
			//open connection
			Connection con = DriverManager.getConnection(url , username , password);
			String sql = "INSERT INTO USER2 (COUNTRY, CAPITAL) VALUES (?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, country);
			ps.setString(2, capital);
			ps.executeUpdate();
			
			
			//close connection
			con.close();
		}catch(Exception e) {
			e.printStackTrace();
		}

}




}

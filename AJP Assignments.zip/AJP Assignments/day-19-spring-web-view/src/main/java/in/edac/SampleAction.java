package in.edac;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/sample")
public class SampleAction {
	

	
	@GetMapping("/home-view")
	public String homeView() {
		return "home";
	}
	
	@GetMapping("/home-view-v1")
	public ModelAndView homeviewV1() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		return mv;
	}
	
	
	@GetMapping("/home-view-v2")
	public ModelAndView homeView2() {
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		
		mv.addObject("title","TITLE BY mv.addObject");
		
		List<String> cityList = Arrays.asList("NAGPUR","KOLKATA","MUMBAI","CHENNAI");
		mv.addObject("cityList", cityList);
//		cityList.stream()
		
		
		
		return mv;
	}
	
	
	
	
	
	@GetMapping("/home-view-v4")
	public ModelAndView homeView4() {
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		
		mv.addObject("title","TITLE BY mv.addObject");
		
		List<String> cityList = Arrays.asList("NAGPUR","KOLKATA","MUMBAI","CHENNAI");
		mv.addObject("cityList", cityList);
		
		List<User> userlist = new ArrayList<User>();
		userlist.add(new User(1,"A","123","A@gmail.com","343432432"));
		userlist.add(new User(2,"B","1223","B@gmail.com","343432432"));
		userlist.add(new User(1,"C","123","C@gmail.com","343432432"));
		userlist.add(new User(1,"D","123","D@gmail.com","343432432"));
		mv.addObject("userList", userlist);
		
		
		
		
		
		return mv;
	}
	
	
	
	@GetMapping("/home-view-v5")
	public ModelAndView homeView5(String q) {
		
		ModelAndView mv = new ModelAndView("home");
		
		if("1".equals(q)) {
			mv.setViewName("register");
		}
		
		mv.addObject("title","TITLE BY mv.addObject "+q);
		
		List<String> cityList = Arrays.asList("NAGPUR","KOLKATA","MUMBAI","CHENNAI");
		mv.addObject("cityList", cityList);
		
		List<User> userlist = new ArrayList<User>();
		userlist.add(new User(1,"A","123","A@gmail.com","343432432"));
		userlist.add(new User(2,"B","1223","B@gmail.com","343432432"));
		userlist.add(new User(1,"C","123","C@gmail.com","343432432"));
		userlist.add(new User(1,"D","123","D@gmail.com","343432432"));
		mv.addObject("userList", userlist);
		
		
		
		
		
		return mv;
	}
	
	
	
}

package in.edac;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class HelloAction {

	/*
	 * http://localhost:8080/hello/
	 * 
	 */
	@GetMapping("/hello")
	public String sayHello() {
		return "hello";
	}
	
	@GetMapping("/hi")
	public String sayhi() {
		return "hi";
	}
	
	@GetMapping("/register")
	public String register() {
		return "register";
	}
	
}

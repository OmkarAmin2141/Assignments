package in.edac.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateMain {

	public static final  SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

	public static void main(String[] args) {
		
		
//		createJointRecord();
		readRecord();
		
	}
	
	
public static void readRecord() {
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		Student st =  session.find(Student.class, 2);
		System.out.println(st);
		
		session.getTransaction().commit();
		
		System.out.println("SUCCESS !!!");
		
		session.close();
		
		
	}
	
	
	
	
	
	
	
	public static void createJointRecord() {
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		Student s1 = new Student("Omkar");
		Address a1 = new Address("Nagpur","MH");
		
		s1.setAddress(a1);
		
		session.save(s1);
		session.save(a1);
		
		
		
		session.getTransaction().commit();
		
		System.out.println("SUCCESS !!!");
		
		session.close();
		
		
	}
	
	

}

package in.edac;

import java.util.List;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import com.mysql.cj.xdevapi.SessionFactory;

public class HelloHibernate {
    public static final org.hibernate.SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args) {
		
//	    createDemo();
//		updateDemo();
//		deleteDemo();
		readAll();
	
	}
	
public static void readAll() {
		
		Session session = sessionFactory.openSession();
		//HQL
		List<Student> list =  session.createQuery("FROM Student",Student.class).list();
		
		list.stream().map(std -> std.getUsername()).forEach(System.out::println);
		
		
		session.close();
		
	}
	
	
	
	
	
	public static void deleteDemo() {
		
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Student std = new Student();
		std.setId(1);
		session.delete(std);
		tx.commit();
		System.out.println("deleted SUCCESSFULL");
		session.close();
		
	}
	
	
	
	
	
	public static void updateDemo() {
		
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Student std = new Student();
		std.setId(1);
		std.setUsername("omkar amin");
		session.update(std);
		tx.commit();
		System.out.println("UPDATED SUCCESSFULL");
		session.close();
		
	}
	
	
	
	
	
	
	public static void createDemo() {
		Session session =  sessionFactory.openSession();
	    
	    Transaction tx = session.beginTransaction();
	    Student std = new Student();
	    std.setUsername("Shubham");
	    std.setPassword("1234222");
	    std.setEmail("shubham@gmail.com");
	    std.setMobile("9098989777");
	    
	    // IMP SAVING THE STATE USING HIBERNATE
	    
	    session.save(std);
	    
	    tx.commit();
	    System.out.println("USER ADDED SUCCESSFULLY");
	    session.close();
	}
	
	

}

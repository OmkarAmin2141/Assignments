package com.java.EDAC;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

class Alumni extends EDACAlumni implements AcademicsDetails{
	private String name;
	private int batch;
	private int rollNo;
	public static String Address="EDAC, Mumbai-410210"; 
	private int marks;
	private long contact;
	private String companyName;
	Alumni aobj1[];		//ARRAY OF OBJECT - REFERENCE VARIABEL
	String c="";
	
	public static final Scanner sc=new Scanner(System.in);
	

	Alumni(){}
	
	 Alumni(String name,int rollNo,int batch,int marks,String companyName,long contact)
	{
		this.name=name;
		this.batch=batch;
		this.rollNo=rollNo;
		this.marks=marks;
		this.contact=contact;
		this.companyName=companyName;
		

	}
	
	
void InsertData(int number) 
{
	Scanner sc=new Scanner(System.in);
	
	
	this.aobj1=new Alumni[number];
	
	for(int i=0;i<number;i++)
		{
			System.out.println("Enter the Data for   Alumni "+(i+1)+":");
			
			System.out.print("Enter your Name :  ");
			String n=sc.next();
			sc.nextLine();
			System.out.print("Enter your Roll No. :  ");
			int r=sc.nextInt();
			System.out.print("Enter your Batch :  ");
			int b=sc.nextInt();
			System.out.print("Enter your total marks :  ");
			int m=sc.nextInt();
			System.out.print("Enter your contact No. :  ");
			long phone=sc.nextLong();
			
			System.out.println("Enter Company Name : ");
			String cName=sc.next();
				
				aobj1[i]=new Alumni(n,r,b,m,cName,phone);			//OBJECT CREATED
		}	
		
			
	
		
	}


	void display(int n)
	{
		do {
			System.out.printf("\n    1. Show All Data   \n    2. Press to get Data Of Perticular Alumni     3. Year Vise Data  \n");
			
			int i=sc.nextInt();
			switch(i)
			{
					case 1:
							for(int i1=0;i1<n;i1++)
							{
								super.display();
								System.out.println("Name : "+aobj1[i1].name+"        "+"Roll No. : "+aobj1[i1].rollNo+"        "+"Batch : "+aobj1[i1].batch+"        Total : "+aobj1[i1].marks+"        Address : "+Address);
								System.out.println("Company Name : "+aobj1[i1].companyName+"     Contact Details : "+aobj1[i1].contact);
								System.out.println();
								
							}
							break;
							
					case 2:
						for(int i2=0;i2<n;i2++)
							System.out.print("\n  "+(i2+1)+"");
							int x=sc.nextInt();
							
							for(int i3=0;i3<n;i3++)
							{
									if((x-1)==i3) {
										System.out.println("Name : "+aobj1[i3].name+"        "+"Roll No. : "+aobj1[i3].rollNo+"        "+"Batch : "+aobj1[i3].batch+"        Total : "+aobj1[i3].marks+"        Address : "+Address);
										System.out.println("Company Name : "+aobj1[i3].companyName+"     Contact Details : "+aobj1[i3].contact);
										System.out.println();
									}
							}
							
							
					case 3:
						System.out.print("\n   1. 2019     2. 2020\n");
						int q=sc.nextInt();
						String s;
						if(q==1)
						{
							q=2019;
							s="PG-DAC Alumni";
						}
						else
						{
							q=2020;
							s="e-DAC Alumni";
						}
						for(int i3=0;i3<n;i3++)
						{
								if(q==aobj1[i3].batch)
								{
									System.out.println("-----------------"+s+"-----------------");
									System.out.println("Name : "+aobj1[i3].name+"        "+"Roll No. : "+aobj1[i3].rollNo+"        "+"Batch : "+aobj1[i3].batch+"        Total : "+aobj1[i3].marks+"        Address : "+Address);
									System.out.println("Company Name : "+aobj1[i3].companyName+"     Contact Details : "+aobj1[i3].contact);
									System.out.println();
								}
						}
						
					System.out.println("Do you want to continue: press Y/N");
					c= sc.next();
			
			}
		}while(c.equals("Y") || c.equals("y"));
	
	}
	
	 
		
		
	void markSheet(int number)			//Insertion sort
	{
		int temp,j;
		for(int i=1;i<number;i++)
		{
			temp=aobj1[i].marks;			//11 	22		 33			temp=22			i=1			j=1
			j=i;
			while(j>0 && aobj1[j-1].marks<temp)
			{
				aobj1[j].marks=aobj1[j-1].marks;
				j=j-1;
			}
			aobj1[j].marks=temp;
		}
		
		
		System.out.println("   ******************************");
		super.timeDate();
		System.out.println("   "+Address);
		System.out.println("   ******************************");
		for(int g=0;g<number;g++)
		{
			
			System.out.println("  RANK "+(g+1)+    "    "+aobj1[g].name+"      "+aobj1[g].marks);
		
		}
		System.out.println("   ******************************");
	}


}


		
		
		

		
		
		

		
		
		
		

		
		
		
		

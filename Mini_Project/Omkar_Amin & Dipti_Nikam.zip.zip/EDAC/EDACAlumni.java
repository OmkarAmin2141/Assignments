package com.java.EDAC;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class EDACAlumni implements AcademicsDetails {
	

		
		
		public void  timeDate()
		  {
		  
			  DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd     HH:mm:ss");
		   
			  LocalDateTime now = LocalDateTime.now();

			   System.out.println("   Date :"+dtf.format(now));

			
		  }
		
		public void display()
		{
			System.out.println("Alumni of DAC Batch");
		}
}

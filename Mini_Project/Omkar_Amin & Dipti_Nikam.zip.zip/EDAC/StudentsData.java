package com.java.EDAC;

public class StudentsData extends Alumni {

	StudentsData(String name, int rollNo, int batch) {
		super(name, rollNo, batch);
		
	}

}

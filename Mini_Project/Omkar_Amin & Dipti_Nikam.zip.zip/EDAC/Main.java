package com.java.EDAC;
import java.util.*;
public class Main {


	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Alumni m=new Alumni();
		System.out.println("       ***** MAIN MENU *****\n");
		System.out.print("Enter the Number of Alumni :");
		int option,n;
		
		n=sc.nextInt();
		String c="";
		do {
		
		 System.out.printf("\n 1. 	Insert Data \n 2. 	Display \n 3.     Marksheet  \n 4.     Exit");
		System.out.print("\n\nSelect Your Choice : ");
		option=sc.nextInt();
		switch(option)
		{
			case 1:
					m.InsertData(n);
				break;
			case 2:
					System.out.println("Display Details : ");
					m.display(n);
					break;
				
			case 3:
					m.markSheet(n);
					break;
					
			case 4: System.exit(0); 
					break;
			default:
				System.out.println("Invalid Input");
				break;
		}
		System.out.println("Do you want to continue: press Y/N");
		c= sc.next();
		
		}while(c.equals("Y") || c.equals("y"));

	}
	
	


}

package com.java.EDAC;

interface AcademicsDetails {

	void  timeDate();
	void display();
	
}
